File Guide

All files that start with "sample" are the files for the sample dataset present in the PDF.

web-Google.txt, w, page_embeddings.json, output-after-iteration-1 are the files you need to refer to when using the complete dataset.
(Remeber to generate the adjacency list using your Task 1 code for web-Google.txt)
